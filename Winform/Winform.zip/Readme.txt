C# Winform:
1. Extract .rar
2. Attach file database into SQL Server
3. Run final.sln file
5. Username: admin
   Password: admin
4. Change the connection path in file Connection.cs into your server name
5. Have fun :)

C# Webform MVC:
1. Extract zip file (include query,mdf,log and .sln file)
2. Attach file database into SQL Server or create new db using query without value
3. Run WebAppECartDemo
4. Have Fun <3