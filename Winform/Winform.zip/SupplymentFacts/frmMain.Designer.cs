﻿namespace SupplymentFacts
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.label1 = new System.Windows.Forms.Label();
            this.đăngNhậpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.hệThốngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngNhậpToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.xemDanhMụcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.AgentListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.EmployeeListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ImportListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ExportListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OrderlistToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dAnhMụcDòngPhiếuXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýDanhMụcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýKháchHàngToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýVậtTưToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýNhânViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýPhiếuNhậpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýPhiếuXuấtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.warehouseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bestSellingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stockinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stockOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.revenueReportMonthlyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(101, 38);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(681, 38);
            this.label1.TabIndex = 1;
            this.label1.Text = "Warehouse management of Supplement Facts";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // đăngNhậpToolStripMenuItem
            // 
            this.đăngNhậpToolStripMenuItem.Name = "đăngNhậpToolStripMenuItem";
            this.đăngNhậpToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.đăngNhậpToolStripMenuItem.Text = "Đăng nhập";
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.thoátToolStripMenuItem.Text = "Thoát";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hệThốngToolStripMenuItem,
            this.xemDanhMụcToolStripMenuItem,
            this.quảnLýDanhMụcToolStripMenuItem,
            this.statiToolStripMenuItem,
            this.reportToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(876, 29);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // hệThốngToolStripMenuItem
            // 
            this.hệThốngToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.đăngNhậpToolStripMenuItem1,
            this.thoátToolStripMenuItem1});
            this.hệThốngToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.hệThốngToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.hệThốngToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("hệThốngToolStripMenuItem.Image")));
            this.hệThốngToolStripMenuItem.Name = "hệThốngToolStripMenuItem";
            this.hệThốngToolStripMenuItem.Size = new System.Drawing.Size(98, 25);
            this.hệThốngToolStripMenuItem.Text = "System";
            // 
            // đăngNhậpToolStripMenuItem1
            // 
            this.đăngNhậpToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("đăngNhậpToolStripMenuItem1.Image")));
            this.đăngNhậpToolStripMenuItem1.Name = "đăngNhậpToolStripMenuItem1";
            this.đăngNhậpToolStripMenuItem1.Size = new System.Drawing.Size(133, 26);
            this.đăngNhậpToolStripMenuItem1.Text = "Login";
            this.đăngNhậpToolStripMenuItem1.Click += new System.EventHandler(this.đăngNhậpToolStripMenuItem1_Click);
            // 
            // thoátToolStripMenuItem1
            // 
            this.thoátToolStripMenuItem1.Name = "thoátToolStripMenuItem1";
            this.thoátToolStripMenuItem1.Size = new System.Drawing.Size(133, 26);
            this.thoátToolStripMenuItem1.Text = "Exit";
            this.thoátToolStripMenuItem1.Click += new System.EventHandler(this.thoátToolStripMenuItem1_Click);
            // 
            // xemDanhMụcToolStripMenuItem
            // 
            this.xemDanhMụcToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AgentListToolStripMenuItem,
            this.EmployeeListToolStripMenuItem,
            this.ImportListToolStripMenuItem,
            this.ExportListToolStripMenuItem,
            this.OrderlistToolStripMenuItem,
            this.dAnhMụcDòngPhiếuXuấtToolStripMenuItem});
            this.xemDanhMụcToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.xemDanhMụcToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("xemDanhMụcToolStripMenuItem.Image")));
            this.xemDanhMụcToolStripMenuItem.Name = "xemDanhMụcToolStripMenuItem";
            this.xemDanhMụcToolStripMenuItem.Size = new System.Drawing.Size(100, 25);
            this.xemDanhMụcToolStripMenuItem.Text = "Catalog";
            // 
            // AgentListToolStripMenuItem
            // 
            this.AgentListToolStripMenuItem.Name = "AgentListToolStripMenuItem";
            this.AgentListToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.AgentListToolStripMenuItem.Text = "Agent list";
            this.AgentListToolStripMenuItem.Click += new System.EventHandler(this.danhMụcKháchHàngToolStripMenuItem_Click);
            // 
            // EmployeeListToolStripMenuItem
            // 
            this.EmployeeListToolStripMenuItem.Name = "EmployeeListToolStripMenuItem";
            this.EmployeeListToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.EmployeeListToolStripMenuItem.Text = "Employee list";
            this.EmployeeListToolStripMenuItem.Click += new System.EventHandler(this.danhMụcNhânViênToolStripMenuItem_Click);
            // 
            // ImportListToolStripMenuItem
            // 
            this.ImportListToolStripMenuItem.Name = "ImportListToolStripMenuItem";
            this.ImportListToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.ImportListToolStripMenuItem.Text = "Import list";
            this.ImportListToolStripMenuItem.Click += new System.EventHandler(this.danhMụcPhiếuNhậpToolStripMenuItem_Click);
            // 
            // ExportListToolStripMenuItem
            // 
            this.ExportListToolStripMenuItem.Name = "ExportListToolStripMenuItem";
            this.ExportListToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.ExportListToolStripMenuItem.Text = "Export list";
            this.ExportListToolStripMenuItem.Click += new System.EventHandler(this.danhMụcPhiếuXuấtToolStripMenuItem_Click);
            // 
            // OrderlistToolStripMenuItem
            // 
            this.OrderlistToolStripMenuItem.Name = "OrderlistToolStripMenuItem";
            this.OrderlistToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.OrderlistToolStripMenuItem.Text = "Order list";
            this.OrderlistToolStripMenuItem.Click += new System.EventHandler(this.danhMụcDòngPhiếuNhậpToolStripMenuItem_Click);
            // 
            // dAnhMụcDòngPhiếuXuấtToolStripMenuItem
            // 
            this.dAnhMụcDòngPhiếuXuấtToolStripMenuItem.Name = "dAnhMụcDòngPhiếuXuấtToolStripMenuItem";
            this.dAnhMụcDòngPhiếuXuấtToolStripMenuItem.Size = new System.Drawing.Size(193, 26);
            this.dAnhMụcDòngPhiếuXuấtToolStripMenuItem.Text = "Warehouse";
            this.dAnhMụcDòngPhiếuXuấtToolStripMenuItem.Click += new System.EventHandler(this.dAnhMụcDòngPhiếuXuấtToolStripMenuItem_Click);
            // 
            // quảnLýDanhMụcToolStripMenuItem
            // 
            this.quảnLýDanhMụcToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýKháchHàngToolStripMenuItem,
            this.quảnLýVậtTưToolStripMenuItem,
            this.quảnLýNhânViênToolStripMenuItem,
            this.quảnLýPhiếuNhậpToolStripMenuItem,
            this.quảnLýPhiếuXuấtToolStripMenuItem,
            this.warehouseToolStripMenuItem});
            this.quảnLýDanhMụcToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.quảnLýDanhMụcToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("quảnLýDanhMụcToolStripMenuItem.Image")));
            this.quảnLýDanhMụcToolStripMenuItem.Name = "quảnLýDanhMụcToolStripMenuItem";
            this.quảnLýDanhMụcToolStripMenuItem.Size = new System.Drawing.Size(140, 25);
            this.quảnLýDanhMụcToolStripMenuItem.Text = "Management";
            this.quảnLýDanhMụcToolStripMenuItem.Click += new System.EventHandler(this.quảnLýDanhMụcToolStripMenuItem_Click);
            // 
            // quảnLýKháchHàngToolStripMenuItem
            // 
            this.quảnLýKháchHàngToolStripMenuItem.Name = "quảnLýKháchHàngToolStripMenuItem";
            this.quảnLýKháchHàngToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.quảnLýKháchHàngToolStripMenuItem.Text = "Agent";
            this.quảnLýKháchHàngToolStripMenuItem.Click += new System.EventHandler(this.quảnLýKháchHàngToolStripMenuItem_Click);
            // 
            // quảnLýVậtTưToolStripMenuItem
            // 
            this.quảnLýVậtTưToolStripMenuItem.Name = "quảnLýVậtTưToolStripMenuItem";
            this.quảnLýVậtTưToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.quảnLýVậtTưToolStripMenuItem.Text = "Order";
            this.quảnLýVậtTưToolStripMenuItem.Click += new System.EventHandler(this.quảnLýVậtTưToolStripMenuItem_Click);
            // 
            // quảnLýNhânViênToolStripMenuItem
            // 
            this.quảnLýNhânViênToolStripMenuItem.Name = "quảnLýNhânViênToolStripMenuItem";
            this.quảnLýNhânViênToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.quảnLýNhânViênToolStripMenuItem.Text = "Employee";
            this.quảnLýNhânViênToolStripMenuItem.Click += new System.EventHandler(this.quảnLýNhânViênToolStripMenuItem_Click);
            // 
            // quảnLýPhiếuNhậpToolStripMenuItem
            // 
            this.quảnLýPhiếuNhậpToolStripMenuItem.Name = "quảnLýPhiếuNhậpToolStripMenuItem";
            this.quảnLýPhiếuNhậpToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.quảnLýPhiếuNhậpToolStripMenuItem.Text = "Import";
            this.quảnLýPhiếuNhậpToolStripMenuItem.Click += new System.EventHandler(this.quảnLýPhiếuNhậpToolStripMenuItem_Click);
            // 
            // quảnLýPhiếuXuấtToolStripMenuItem
            // 
            this.quảnLýPhiếuXuấtToolStripMenuItem.Name = "quảnLýPhiếuXuấtToolStripMenuItem";
            this.quảnLýPhiếuXuấtToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.quảnLýPhiếuXuấtToolStripMenuItem.Text = "Export";
            this.quảnLýPhiếuXuấtToolStripMenuItem.Click += new System.EventHandler(this.quảnLýPhiếuXuấtToolStripMenuItem_Click);
            // 
            // warehouseToolStripMenuItem
            // 
            this.warehouseToolStripMenuItem.Name = "warehouseToolStripMenuItem";
            this.warehouseToolStripMenuItem.Size = new System.Drawing.Size(177, 26);
            this.warehouseToolStripMenuItem.Text = "Warehouse";
            // 
            // statiToolStripMenuItem
            // 
            this.statiToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("statiToolStripMenuItem.BackgroundImage")));
            this.statiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bestSellingToolStripMenuItem,
            this.stockinToolStripMenuItem,
            this.stockOutToolStripMenuItem,
            this.revenueReportMonthlyToolStripMenuItem});
            this.statiToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.statiToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("statiToolStripMenuItem.Image")));
            this.statiToolStripMenuItem.Name = "statiToolStripMenuItem";
            this.statiToolStripMenuItem.Size = new System.Drawing.Size(109, 25);
            this.statiToolStripMenuItem.Text = " Statistic";
            this.statiToolStripMenuItem.Click += new System.EventHandler(this.statiToolStripMenuItem_Click);
            // 
            // bestSellingToolStripMenuItem
            // 
            this.bestSellingToolStripMenuItem.Name = "bestSellingToolStripMenuItem";
            this.bestSellingToolStripMenuItem.Size = new System.Drawing.Size(276, 26);
            this.bestSellingToolStripMenuItem.Text = "Best-Selling";
            this.bestSellingToolStripMenuItem.Click += new System.EventHandler(this.bestSellingToolStripMenuItem_Click);
            // 
            // stockinToolStripMenuItem
            // 
            this.stockinToolStripMenuItem.Name = "stockinToolStripMenuItem";
            this.stockinToolStripMenuItem.Size = new System.Drawing.Size(276, 26);
            this.stockinToolStripMenuItem.Text = "Stock-In";
            this.stockinToolStripMenuItem.Click += new System.EventHandler(this.stockinToolStripMenuItem_Click);
            // 
            // stockOutToolStripMenuItem
            // 
            this.stockOutToolStripMenuItem.Name = "stockOutToolStripMenuItem";
            this.stockOutToolStripMenuItem.Size = new System.Drawing.Size(276, 26);
            this.stockOutToolStripMenuItem.Text = "Stock-Out";
            this.stockOutToolStripMenuItem.Click += new System.EventHandler(this.stockOutToolStripMenuItem_Click_1);
            // 
            // revenueReportMonthlyToolStripMenuItem
            // 
            this.revenueReportMonthlyToolStripMenuItem.Name = "revenueReportMonthlyToolStripMenuItem";
            this.revenueReportMonthlyToolStripMenuItem.Size = new System.Drawing.Size(276, 26);
            this.revenueReportMonthlyToolStripMenuItem.Text = "Revenue Report Monthly";
            this.revenueReportMonthlyToolStripMenuItem.Click += new System.EventHandler(this.revenueReportMonthlyToolStripMenuItem_Click);
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printToolStripMenuItem});
            this.reportToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.reportToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("reportToolStripMenuItem.Image")));
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(94, 25);
            this.reportToolStripMenuItem.Text = "Report";
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(232, 26);
            this.printToolStripMenuItem.Text = "Print Delivery Slips";
            this.printToolStripMenuItem.Click += new System.EventHandler(this.printToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 9.75F);
            this.helpToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("helpToolStripMenuItem.Image")));
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(82, 25);
            this.helpToolStripMenuItem.Text = " Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // frmMain
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(876, 336);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmMain";
            this.Text = "Warehouse management";
            this.Load += new System.EventHandler(this.frmChinh_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem đăngNhậpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem hệThốngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đăngNhậpToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem xemDanhMụcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem AgentListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem EmployeeListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ImportListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ExportListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem OrderlistToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dAnhMụcDòngPhiếuXuấtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýDanhMụcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýKháchHàngToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýNhânViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýPhiếuNhậpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýPhiếuXuấtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýVậtTưToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem warehouseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem statiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bestSellingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stockinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stockOutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem revenueReportMonthlyToolStripMenuItem;
    }
}

